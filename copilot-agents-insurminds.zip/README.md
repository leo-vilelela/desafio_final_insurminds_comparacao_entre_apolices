# Time de Agentes de Engenharia — GitHub Copilot (VS Code, plano Free)

## Instalação
1. Copie a pasta `.github/` para a **raiz** do seu repositório/workspace (no WSL2: `cp -r .github ~/projetos/meu-repo/`).
2. Abra a pasta no VS Code (extensão *GitHub Copilot* + *Copilot Chat* atualizadas, logado no GitHub).
3. Confirme em **Settings → Chat → Instructions** que estão habilitados:
   - `github.copilot.chat.codeGeneration.useInstructionFiles` (lê `copilot-instructions.md` e `*.instructions.md`);
   - Prompt files e Custom agents (nomes das opções variam conforme a versão).

## Como usar
| Recurso | Arquivo | Como acionar |
|---|---|---|
| Instruções globais (roteamento) | `.github/copilot-instructions.md` | Automático em todo chat |
| Regras por tipo de arquivo | `.github/instructions/*.instructions.md` | Automático via `applyTo` |
| Agentes especialistas | `.github/agents/*.agent.md` | Seletor de agente/modo no Chat |
| Comandos de barra | `.github/prompts/*.prompt.md` | Digite `/java`, `/angular`, `/python-ia`, `/devops`, `/banco-de-dados`, `/desafio3`, `/desafio4`, `/desafio5`, `/projeto-final`, `/checklist-entrega` |

Dica: anexe o arquivo aberto com `#file` ou selecione um trecho antes de perguntar — economiza mensagens do plano gratuito.

## Observações
- Versões antigas do VS Code usam `.github/chatmodes/*.chatmode.md`; se o seletor não listar os agentes, mova/renomeie os arquivos de `agents/*.agent.md` para `chatmodes/*.chatmode.md`.
- Se algum recurso não aparecer no plano Free ou na sua versão, os arquivos `copilot-instructions.md` + `instructions/` funcionam sozinhos; use os `.agent.md` como texto colado no chat.
- Nunca coloque chaves de API nestes arquivos nem no repositório.
