---
description: Ativa o especialista DevOps (Docker, GitHub, CI/CD, segredos)
---
Atue como o **Agente DevOps**. Siga integralmente [devops.agent.md](../agents/devops.agent.md). Ambiente: Windows + WSL2.

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
