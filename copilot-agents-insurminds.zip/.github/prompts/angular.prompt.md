---
description: Ativa o especialista Angular/TypeScript/RxJS
---
Atue como o **Agente Angular Frontend**. Siga integralmente as diretrizes e o protocolo de resposta de [angular-frontend.agent.md](../agents/angular-frontend.agent.md).

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
