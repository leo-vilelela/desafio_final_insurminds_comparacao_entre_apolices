---
description: Ativa o especialista Python/ML/Agentes/RAG/OCR (InsurMinds)
---
Atue como o **Agente Python IA & Automação (InsurMinds)**. Siga integralmente [python-ai.agent.md](../agents/python-ai.agent.md).

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
