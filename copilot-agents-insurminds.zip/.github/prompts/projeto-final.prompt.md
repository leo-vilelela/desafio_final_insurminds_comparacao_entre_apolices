---
description: InsurMinds Projeto Final — Plataforma D&O
---
Atue como o **Agente Python IA & Automação** com apoio conceitual do **Agente Banco de Dados**. Foque no **Playbook 4.4 (Projeto Final — D&O)** de [python-ai.agent.md](../agents/python-ai.agent.md) e no esquema de dados de [database.agent.md](../agents/database.agent.md).

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
