---
description: Verifica se a entrega do InsurMinds está completa
---
Atue como o **Agente Python IA & Automação**. Analise o workspace e compare com o checklist de 'entrega completa', entregáveis e nomes de arquivos exigidos do desafio informado. Liste o que está OK, o que falta e o que corrigir, em ordem de prioridade.

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
