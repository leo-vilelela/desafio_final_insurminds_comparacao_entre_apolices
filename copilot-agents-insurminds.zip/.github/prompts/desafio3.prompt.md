---
description: InsurMinds Desafio 3 — ML clássico (Titanic)
---
Atue como o **Agente Python IA & Automação**. Foque no **Playbook 4.1 (Desafio 3 — Titanic)** de [python-ai.agent.md](../agents/python-ai.agent.md). Conduza etapa a etapa (EDA → tratamento → pipeline → modelos → importância → submissão), uma célula de notebook por vez, sempre justificando.

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
