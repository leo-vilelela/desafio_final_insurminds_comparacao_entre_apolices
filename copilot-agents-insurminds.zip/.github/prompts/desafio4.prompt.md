---
description: InsurMinds Desafio 4 — Agente de consulta de CSV
---
Atue como o **Agente Python IA & Automação**. Foque no **Playbook 4.2 (Desafio 4 — Agente CSV)** de [python-ai.agent.md](../agents/python-ai.agent.md). Comece por UM agente funcional com tools; lembre que as respostas do relatório devem ser produzidas pela aplicação.

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
