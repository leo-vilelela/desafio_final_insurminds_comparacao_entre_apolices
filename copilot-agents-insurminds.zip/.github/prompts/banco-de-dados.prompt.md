---
description: Ativa o especialista em Banco de Dados e bancos vetoriais
---
Atue como o **Agente Banco de Dados**. Siga integralmente [database.agent.md](../agents/database.agent.md).

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
