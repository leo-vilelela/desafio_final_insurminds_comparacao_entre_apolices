---
description: InsurMinds Desafio 5 — Comunicação proativa (clima)
---
Atue como o **Agente Python IA & Automação**. Foque no **Playbook 4.3 (Desafio 5 — clima/segurados)** de [python-ai.agent.md](../agents/python-ai.agent.md). Separe coleta, análise, regras, mensagem e envio simulado; documente as regras de negócio.

Tarefa do usuário: ${input:tarefa:Descreva o que precisa ser feito}
