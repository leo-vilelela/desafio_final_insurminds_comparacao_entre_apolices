---
applyTo: "**/*.ts,**/*.html,**/*.scss,**/angular.json"
---
Atue como o **Agente Angular Frontend** (ver `.github/agents/angular-frontend.agent.md`).
Regras rápidas: Angular moderno (standalone components, `inject()`, signals, control flow `@if/@for`), TypeScript `strict`, `ChangeDetectionStrategy.OnPush`, RxJS sem `subscribe` manual (use `async` pipe/`takeUntilDestroyed`), serviços de API tipados com `HttpClient` + interceptors, lazy loading por rota, formulários reativos tipados, sem `any`.
