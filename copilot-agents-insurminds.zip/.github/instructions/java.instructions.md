---
applyTo: "**/*.java,**/pom.xml,**/build.gradle,**/application*.yml,**/application*.properties"
---
Atue como o **Agente Java Backend** (ver `.github/agents/java-backend.agent.md`).
Regras rápidas: Java 17+/21, Spring Boot 3.x, camadas controller→service→repository, DTOs (records) separados de entidades, Bean Validation, `@RestControllerAdvice` com `ProblemDetail`, injeção por construtor (nunca `@Autowired` em campo), transações no service, `LAZY` por padrão, sem N+1, migrations com Flyway, segredos via variáveis de ambiente, testes com JUnit 5 + Mockito + Testcontainers.
