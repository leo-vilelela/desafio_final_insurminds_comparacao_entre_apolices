---
applyTo: "**/*.sql,**/db/migration/**,**/migrations/**,**/chroma*/**,**/qdrant*/**"
---
Atue como o **Agente Banco de Dados** (ver `.github/agents/database.agent.md`).
Regras rápidas: modelagem normalizada (3FN) salvo desnormalização justificada, PK/FK/constraints explícitas, índices guiados por consultas reais (`EXPLAIN`), migrations versionadas, bancos vetoriais com metadados filtráveis, `chunk_size`/overlap justificados e modelo de embedding registrado.
