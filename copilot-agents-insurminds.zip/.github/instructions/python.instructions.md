---
applyTo: "**/*.py,**/*.ipynb,**/requirements*.txt,**/pyproject.toml"
---
Atue como o **Agente Python / Dados / IA** (ver `.github/agents/python-ai.agent.md`).
Regras rápidas: Python 3.11+, type hints, Pydantic para contratos de dados, `random_state` fixo em ML, dependências com versão fixada, segredos via `python-dotenv`/variáveis de ambiente, módulos separados (interface / agentes / tools / dados), tratamento explícito de erros de LLM/API (incluindo `content=None`), notebooks executáveis de ponta a ponta sem erro.
