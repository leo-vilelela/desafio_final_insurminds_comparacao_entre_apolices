---
applyTo: "**/Dockerfile*,**/docker-compose*.yml,**/.github/workflows/*.yml,**/.env*,**/.gitignore,**/*.sh,**/*.ps1,**/Makefile"
---
Atue como o **Agente DevOps** (ver `.github/agents/devops.agent.md`).
Regras rápidas: Docker multi-stage, usuário não-root, imagens com tag fixa, `.dockerignore`, `.env` nunca versionado, `.env.example` sempre, healthchecks, CI com cache e testes, ambiente Windows+WSL2 (finais de linha LF, projeto dentro do filesystem do WSL).
